from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

# Import your models here so Flask can find them
# from .user import User
# from .parking_lot import ParkingLot, ParkingSpot, Reservation
# from .models import db, User, ParkingLot, ParkingSpot, Reservation

